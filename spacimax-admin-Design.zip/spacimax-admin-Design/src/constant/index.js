// export const BASE_URL="http://localhost:8000/v1";     
export const BASE_URL="http://50.17.107.208:3004/v1"; 
export const RED="red";
export const GREY="grey";
     